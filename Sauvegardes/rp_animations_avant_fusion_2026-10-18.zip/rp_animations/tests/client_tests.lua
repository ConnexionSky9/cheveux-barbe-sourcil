-- =====================================================================
--  Tests de la logique client de rp_animations (natives simulées, voir client_mock.lua)
--  Ils vérifient l'enchaînement des appels (lancer, placer, attacher, nettoyer),
--  pas le rendu visuel : celui-ci ne peut être validé qu'en jeu.
-- =====================================================================
Tests = {}
local function T(name, fn) Tests[#Tests + 1] = { name = name, fn = fn } end
local function check(cond, msg) if not cond then error(msg or 'vérification échouée', 2) end end
local function lastNotify()
    local l = CM.NuiMsgs('notify')
    return l[#l] and l[#l].text or ''
end
local ME = 101

local function startDuo(role, anim)
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = anim or 'slow_classique', role = role, partner = 2, offsets = {} })
    Mock.Advance(300)
    local r = CM.Server('rp_animations:sv:ready')
    check(#r == 1 and r[1].args[2] == true, 'prêt attendu (' .. role .. ')')
    CM.FromServer('rp_animations:cl:go', 7, 1)
    Mock.Advance(100)
end

T('Solo : lancer depuis le menu puis /stopanim', function()
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(CM.anims[ME] and CM.anims[ME].c == 'low_center', 'clip joué')
    check(CM.anims[ME].flag == 1, 'en boucle')
    check(RPA.Current() and RPA.Current().e.id == 'solo_lente', 'animation courante')
    Mock.commands['stopanim']()
    check(not RPA.Current(), 'arrêtée')
    check(CM.anims[ME] == nil, 'clip retiré du personnage')
    local cur = CM.NuiMsgs('current')
    check(cur[#cur].id == nil, 'menu informé de l\'arrêt')
end)

T('Solo : la touche d\'arrêt (commande liée) arrête aussi', function()
    CM.Nui('play', { id = 'solo_festive' })
    Mock.Advance(100)
    Mock.commands['rp_animations_stop']()
    check(not RPA.Current() and CM.anims[ME] == nil, 'arrêtée')
end)

T('Solo : avancer arrête l\'animation (StopOnMove)', function()
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    CM.pressed[32] = true
    Mock.Advance(50)
    CM.pressed[32] = nil
    check(not RPA.Current(), 'arrêt au mouvement')
end)

T('Solo : fichiers absents → message clair, rien n\'est joué', function()
    CM.missingDicts['anim@amb@nightclub@mini@dance@dance_solo@female@var_a@'] = true
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(not RPA.Current() and CM.anims[ME] == nil, 'rien joué')
    check(lastNotify():find('indisponible'), 'message : ' .. lastNotify())
end)

T('Animation « à créer » : message clair', function()
    CM.Nui('play', { id = 'valse_classique' })
    check(lastNotify():find('à créer'), 'message : ' .. lastNotify())
    check(not RPA.Current(), 'rien joué')
end)

T('Personnage mort ou en véhicule : refusé', function()
    CM.dead = true
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(not RPA.Current(), 'mort')
    CM.dead, CM.vehicle = false, true
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(not RPA.Current(), 'véhicule')
end)

T('Mort pendant une animation solo : arrêt automatique', function()
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    CM.dead = true
    Mock.Advance(300)
    check(not RPA.Current(), 'arrêtée')
end)

T('Adulte solo : refusé sans l\'option, joué avec', function()
    CM.Nui('play', { id = 'adulte_boite' })
    Mock.Advance(100)
    check(not RPA.Current(), 'refusé sans option')
    CM.Nui('prefs', { adult = true })
    check(#CM.Server('rp_animations:sv:prefs') >= 1, 'préférence envoyée au serveur')
    CM.Nui('play', { id = 'adulte_boite' })
    Mock.Advance(100)
    check(RPA.Current() and RPA.Current().e.id == 'adulte_boite', 'joué avec option')
    CM.Nui('prefs', { adult = false })
    check(not RPA.Current(), 'désactiver l\'option arrête l\'animation adulte')
end)

T('Enchaînement solo cyclique (séduction avec changement de pose)', function()
    CM.Nui('prefs', { adult = true })
    CM.Nui('play', { id = 'adulte_seduction_poses' })
    Mock.Advance(100)
    check(CM.anims[ME].c == 'sexy003', 'pose 1')
    Mock.Advance(6000)
    check(CM.anims[ME].c == 'sexy004', 'pose 2')
    Mock.Advance(12000)
    check(CM.anims[ME].c == 'sexy003', 'retour pose 1')
end)

T('Duo rôle B : marche vers sa place, attache, phase recalée, puis fin propre', function()
    startDuo('B')
    check(CM.walks == 1, 'B marche vers sa place (pas de téléportation)')
    check(CM.attached[ME] and CM.attached[ME].to == 102, 'B attaché à A')
    check(CM.anims[ME] and CM.anims[ME].c == 'mx_couple5_1_b_clip', 'clip du rôle B')
    CM.anims[102] = { d = 'mx_couple5_1_a', c = 'mx_couple5_1_a_clip' }   -- A joue son clip (répliqué)
    Mock.Advance(700)
    check(CM.phaseSet == 0.42, 'phase de B alignée sur A')
    CM.FromServer('rp_animations:cl:ended', 7, 'partenaire', 'Ton ou ta partenaire a arrêté l\'animation')
    check(not RPA.Current(), 'session finie')
    check(CM.attached[ME] == nil, 'détaché')
    check(CM.anims[ME] == nil, 'clip retiré')
end)

T('Duo rôle A : prêt sans bouger, immobile pendant la mise en place, arrêt local immédiat', function()
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = 'slow_classique', role = 'A', partner = 2, offsets = {} })
    Mock.Advance(300)
    check(CM.walks == 0, 'A ne bouge pas')
    check(CM.keys[30] and CM.keys[31], 'déplacements de A bloqués pendant la mise en place')
    CM.FromServer('rp_animations:cl:go', 7, 1)
    Mock.Advance(100)
    check(CM.anims[ME].c == 'mx_couple5_1_a_clip', 'clip du rôle A')
    check(not CM.attached[ME], 'A n\'est pas attaché')
    CM.Nui('stop')
    check(not RPA.Current(), 'arrêt immédiat côté client')
    local s = CM.Server('rp_animations:sv:stop')
    check(#s == 1, 'serveur prévenu')
    CM.keys = {}
    Mock.Advance(100)
    check(not CM.keys[30], 'plus aucun contrôle bloqué après l\'arrêt')
end)

T('Duo : obstacle entre les deux → annulé avant de démarrer', function()
    CM.wall = true
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = 'slow_classique', role = 'B', partner = 2, offsets = {} })
    Mock.Advance(300)
    local r = CM.Server('rp_animations:sv:ready')
    check(#r == 1 and r[1].args[2] == false and r[1].args[3] == 'place', 'refus « place »')
    check(not RPA.Current(), 'nettoyé')
end)

T('Duo : fichiers absents chez moi → le serveur est prévenu', function()
    CM.missingClips['mx_couple5_1_b_clip'] = true
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = 'slow_classique', role = 'B', partner = 2, offsets = {} })
    Mock.Advance(300)
    local r = CM.Server('rp_animations:sv:ready')
    check(#r == 1 and r[1].args[3] == 'fichiers', 'refus « fichiers »')
end)

T('Duo : partenaire hors de portée → arrêt automatique', function()
    startDuo('B')
    CM.partnerVisible = false
    Mock.Advance(300)
    check(not RPA.Current(), 'arrêté')
    check(#CM.Server('rp_animations:sv:stop') == 1, 'serveur prévenu')
    check(not CM.attached[ME], 'détaché')
end)

T('Duo : animation coupée par une autre ressource → session arrêtée', function()
    startDuo('A')
    Mock.Advance(1200)
    CM.anims[ME] = nil
    Mock.Advance(300)
    check(not RPA.Current(), 'arrêté')
    check(CM.Server('rp_animations:sv:stop')[1].args[1] == 'interrompue', 'raison interrompue')
end)

T('Duo : offset calibré utilisé pour attacher B', function()
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = 'slow_classique', role = 'B', partner = 2,
        offsets = { ['1'] = { x = 0.1, y = 0.3, z = 0.0, h = 170.0 } } })
    Mock.Advance(300)
    CM.FromServer('rp_animations:cl:go', 7, 1)
    check(CM.attached[ME].y == 0.3 and CM.attached[ME].x == 0.1, 'offset calibré')
end)

T('Fondu au noir : seulement si choisi, retiré à l\'arrêt', function()
    CM.Nui('prefs', { adult = true })
    startDuo('A', 'adulte_scene_privee')
    CM.FromServer('rp_animations:cl:step', 7, 2)
    Mock.Advance(3000)
    check(#CM.NuiMsgs('fade') == 0, 'pas de fondu sans choix du joueur')
    RPA.Stop('stop')
    CM.server = {}
    -- Cette fois le joueur a coché le fondu en acceptant
    CM.FromServer('rp_animations:cl:invite', { id = 55, anim = 'adulte_scene_privee', label = 'x', from = 'y', adult = true, fade = true, role = 'A' })
    CM.Nui('respond', { id = 55, accept = true, confirmAdult = true, fade = true })
    startDuo('A', 'adulte_scene_privee')
    CM.FromServer('rp_animations:cl:step', 7, 2)
    Mock.Advance(3000)
    local f = CM.NuiMsgs('fade')
    check(#f == 1 and f[1].on == true, 'fondu choisi')
    RPA.Stop('stop')
    f = CM.NuiMsgs('fade')
    check(f[#f].on == false, 'fondu retiré à l\'arrêt')
end)

T('Invitation simple : Y accepte, L refuse', function()
    CM.FromServer('rp_animations:cl:invite', { id = 9, anim = 'slow_classique', label = 'Slow', from = 'Une personne (ID 2)', adult = false, role = 'B' })
    Mock.commands['rp_animations_accept']()
    local r = CM.Server('rp_animations:sv:respond')
    check(#r == 1 and r[1].args[1] == 9 and r[1].args[2] == true and r[1].args[3] == false, 'acceptation envoyée')
    CM.FromServer('rp_animations:cl:invite', { id = 10, anim = 'slow_classique', label = 'Slow', from = 'x', adult = false, role = 'B' })
    Mock.commands['rp_animations_refuse']()
    r = CM.Server('rp_animations:sv:respond')
    check(#r == 2 and r[2].args[2] == false, 'refus envoyé')
end)

T('Invitation adulte : Y ouvre la confirmation, n\'accepte jamais directement', function()
    CM.FromServer('rp_animations:cl:invite', { id = 11, anim = 'adulte_etreinte', label = 'Étreinte', from = 'x', adult = true, role = 'B' })
    Mock.commands['rp_animations_accept']()
    check(#CM.Server('rp_animations:sv:respond') == 0, 'aucune réponse envoyée par la touche')
    check(CM.focus == true, 'menu ouvert sur la confirmation')
    local o = CM.NuiMsgs('open')
    check(o[#o].confirm == 11, 'fenêtre de confirmation demandée')
    CM.Nui('respond', { id = 99, accept = true, confirmAdult = true })
    check(#CM.Server('rp_animations:sv:respond') == 0, 'mauvais identifiant ignoré')
    CM.Nui('respond', { id = 11, accept = true, confirmAdult = true })
    local r = CM.Server('rp_animations:sv:respond')
    check(#r == 1 and r[1].args[3] == true, 'confirmation explicite transmise')
end)

T('Inviter : rôle et cible transmis au serveur', function()
    CM.Nui('invite', { id = 'slow_classique', target = 2, role = 'B' })
    Mock.Advance(100)
    local r = CM.Server('rp_animations:sv:invite')
    check(#r == 1 and r[1].args[1] == 2 and r[1].args[2] == 'slow_classique' and r[1].args[3] == 'B', 'invitation envoyée')
    local near = CM.Nui('nearby')
    check(#near == 1 and near[1].id == 2 and near[1].canInvite, 'joueur proche listé')
end)

T('Menu : ouverture, favoris persistants, fermeture sans contrôles bloqués', function()
    Mock.commands['danses']()
    check(CM.focus == true, 'focus NUI')
    local o = CM.NuiMsgs('open')
    check(#o == 1 and #o[1].catalog.list > 0, 'catalogue envoyé')
    local ids = {}
    for _, e in ipairs(o[1].catalog.list) do ids[e.id] = e end
    check(ids['slow_classique'] and ids['slow_classique'].playable, 'jouable présent')
    check(ids['valse_classique'] and not ids['valse_classique'].playable, '« à créer » présent en grisé')
    CM.Nui('favorite', { id = 'slow_classique', on = true })
    check(Mock.kvp.favorites and Mock.kvp.favorites:find('slow_classique'), 'favori sauvegardé')
    CM.Nui('close')
    check(CM.focus == false, 'focus rendu au jeu')
end)

T('Vérification des fichiers : les fiches dont un clip manque sont marquées', function()
    CM.missingDicts['mx_couple5_1_b'] = true
    local done
    RPA.Anim.CheckAll(function(m) done = m end)
    Mock.Advance(5000)
    check(done, 'vérification terminée')
    check(RPA.Anim.avail['slow_classique'] == false, 'slow_classique indisponible')
    check(RPA.Anim.avail['slow_rapproche'] == true, 'slow_rapproche disponible')
    check(RPA.Anim.avail['valse_classique'] == nil, 'les « à créer » ne sont pas vérifiées')
end)

T('Arrêt de la ressource pendant un duo : personnage libéré', function()
    startDuo('B')
    Mock.Fire('onResourceStop', 'rp_animations')
    check(not CM.attached[ME] and CM.anims[ME] == nil, 'détaché et sans clip')
end)

T('elyzea_animations : sa touche X (export Stop) arrête une danse en duo et prévient le serveur', function()
    startDuo('B')
    check(Mock.exported.Stop and Mock.exported.IsBusy(), 'exports disponibles')
    Mock.exported.Stop()
    check(not RPA.Current() and not CM.attached[ME], 'danse arrêtée et B détaché')
    check(#CM.Server('rp_animations:sv:stop') == 1, 'serveur prévenu')
end)

T('elyzea_animations : son emote / placement est arrêté avant une danse', function()
    local released = 0
    Mock.resources.elyzea_animations = 'started'
    Mock.foreign.elyzea_animations = { StopEmote = function() released = released + 1 end }
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(released == 1 and RPA.Current(), 'emote Elyzea arrêtée avant la danse solo')
    RPA.Stop('stop')
    CM.FromServer('rp_animations:cl:prepare', { sid = 7, anim = 'slow_classique', role = 'A', partner = 2, offsets = {} })
    check(released == 2, 'emote Elyzea arrêtée avant une danse en duo')
end)

T('elyzea_animations : bouton retour vers le menu K et export Open', function()
    local opened = 0
    Mock.resources.elyzea_animations = 'started'
    Mock.foreign.elyzea_animations = { OpenMenu = function() opened = opened + 1 end }
    Mock.exported.Open()
    check(CM.focus == true, 'menu des danses ouvert par export')
    local o = CM.NuiMsgs('open')
    check(o[#o].emotesMenu == true, 'bouton retour affiché')
    CM.Nui('emotesMenu')
    check(CM.focus == false and opened == 1, 'menu K rouvert, menu des danses fermé')
end)

T('Sans elyzea_animations : aucune erreur, pas de bouton retour', function()
    CM.Nui('play', { id = 'solo_lente' })
    Mock.Advance(100)
    check(RPA.Current(), 'danse lancée')
    Mock.exported.Open()
    local o = CM.NuiMsgs('open')
    check(o[#o].emotesMenu == false, 'pas de bouton retour')
end)
